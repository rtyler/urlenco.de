import de.urlenco.UrlRedirect;


public class Tester {

	
	public static void main(String[] args)
	{
		System.out.println(UrlRedirect.encodeUrl("http://www.google.com"));
		System.out.println(UrlRedirect.decodeUrl(UrlRedirect.encodeUrl("http://www.google.com")));
	}
}
