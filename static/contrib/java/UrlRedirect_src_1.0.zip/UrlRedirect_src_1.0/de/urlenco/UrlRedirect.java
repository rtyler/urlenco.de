package de.urlenco;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

public class UrlRedirect {
	private static final String MSG_INVALID_RESULT = "Invalid result returned from API.";
	private static final String MSG_INVALID_RESULT_KEY = "API result missing required key \"%s.\"";

	private static final String KEY_URL = "url";
	private static final String KEY_ENCODED = "encoded";

	private static final String URL_ENCODE = "http://urlenco.de/PostJSON.aspx?encode=%s";
	private static final String URL_DECODE = "http://urlenco.de/PostJSON.aspx?decode=%s";
	
	private HashMap<String, String> getKeyValuePairs(String line)
	{
		HashMap<String,String> result = new HashMap<String,String>();
		String[] pieces = line.split("[{}, ]");
		
		for(int i = 0; i < pieces.length; i++)
		{
			if(pieces[i].length() == 0)
				continue;
			if(i + 2 >= pieces.length || !pieces[i + 1].equals(":"))
				throw new RuntimeException(MSG_INVALID_RESULT);
						
			String key = pieces[i];
			String value = pieces[i + 2];
			
			if(!key.matches("^\".*\"$") || !value.matches("^\".*\"$"))
				throw new RuntimeException(MSG_INVALID_RESULT);
			
			key = key.substring(1, key.length() - 1);
			value = value.substring(1, value.length() - 1);
			
			result.put(key, value);
			i+=2;
		}
		
		return result;
	}
	
	private String getValue(HashMap<String, String> result, String key)
	{
		if(!result.containsKey(key))
			throw new RuntimeException(String.format(MSG_INVALID_RESULT_KEY, key));
		
		return result.get(key);
	}
	
	private String fetchGETResult(String targetUrl)
	{
		String line = null;
		
		try
		{
			URL url = new URL(targetUrl);
			BufferedReader rd = new BufferedReader(new InputStreamReader(url.openStream()));
	        line = rd.readLine();
		} 
		catch(MalformedURLException e)
		{
		}
		catch(IOException e)
		{
		}

        if(line == null)
        	throw new RuntimeException(MSG_INVALID_RESULT);

		return line;
	}
	
	/**
	 * Uses http://urlenco.de service to create a short version of the specified URL
	 * @param url URL to encode
	 * @return URL that will redirect to the specified address
	 */
	public static String encodeUrl(String url)
	{
		UrlRedirect instance = new UrlRedirect();
		
		String line = instance.fetchGETResult(String.format(URL_ENCODE, url));
		HashMap<String,String> keyValuePairs = instance.getKeyValuePairs(line);
		return instance.getValue(keyValuePairs, KEY_ENCODED);
	}
	
	/**
	 * Returns the original URL that was used to create a short version
	 * through http://urlenco.de
	 * @param url URL to decode
	 * @return Original URL
	 */
	public static String decodeUrl(String url)
	{
		UrlRedirect instance = new UrlRedirect();

		String line = instance.fetchGETResult(String.format(URL_DECODE, url));
		HashMap<String,String> keyValuePairs = instance.getKeyValuePairs(line);
		return instance.getValue(keyValuePairs, KEY_URL);
	}
}
